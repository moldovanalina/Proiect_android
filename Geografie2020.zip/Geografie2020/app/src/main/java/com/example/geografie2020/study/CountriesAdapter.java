package com.example.geografie2020.study;

import android.app.Activity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.ahmadrosid.svgloader.SvgLoader;
import com.example.geografie2020.ListAdapter;
import com.example.geografie2020.R;
import com.example.geografie2020.repository.Country;

public
class CountriesAdapter extends ListAdapter<Country,CountriesAdapter.ViewHolder> {


    @Override
    protected ViewHolder createViewHolder(View view) {
        return new ViewHolder(view);
    }

    @Override
    protected View onCreateView(@NonNull ViewGroup parent, int viewType) {
        return LayoutInflater.from(parent.getContext()).inflate(R.layout.countries_item,parent,false);
    }

    @Override
    protected void onSetupView(@NonNull ViewHolder holder, int position, Country item) {
        holder.name.setText(item.name);
        holder.code.setText(item.alpha2Code);
        SvgLoader.pluck().with((Activity) holder.itemView.getContext()).load(item.flag,holder.flag);
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {

        View res= LayoutInflater.from(parent.getContext()).inflate(R.layout.countries_item,parent,false);
        res.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) { onItemSelected.perform((Country) view.getTag(R.id.item));
            }
        });
        return new ViewHolder(res);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        Country country=getItem(position);
        holder.name.setText(country.name);
        holder.code.setText(country.alpha2Code);
        SvgLoader.pluck().with((Activity) holder.itemView.getContext()).load(country.flag,holder.flag);
        holder.itemView.setTag(R.id.item,country);
    }



    static class ViewHolder extends RecyclerView.ViewHolder{

        TextView name;
        TextView code;
        ImageView flag;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);

            name=itemView.findViewById(R.id.name);
            code=itemView.findViewById(R.id.code);
            flag=itemView.findViewById(R.id.flag);
        }
    }
}
