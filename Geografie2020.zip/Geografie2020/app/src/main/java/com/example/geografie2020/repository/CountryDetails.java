package com.example.geografie2020.repository;

import java.util.List;

public class CountryDetails extends Country {

    public int area;
    public int population;
    public List<String> borders;
    public List<String> timezones;

}