package com.example.geografie2020.game;

public class GameResult {

    public int wins;
    public long startTime;
    public long duration;
}
