package com.example.geografie2020;

public interface Action<T> {

    void perform(T args);
}
