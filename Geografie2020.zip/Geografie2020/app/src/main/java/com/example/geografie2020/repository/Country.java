package com.example.geografie2020.repository;

import java.io.Serializable;

public class Country implements Serializable {
    public String name;
    public String alpha2Code;
    public String capital;
    public String flag;
}