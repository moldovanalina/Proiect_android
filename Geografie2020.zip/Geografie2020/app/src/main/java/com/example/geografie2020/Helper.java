package com.example.geografie2020;

import java.lang.reflect.Array;
import java.util.Arrays;
import java.util.List;

public class Helper {

    public static List<String> getContents(){

        return Arrays.asList("Asia","Europe","Africa","Americas","Oceania");
    }

    public static List<Integer>getNrQuestions(){

        return Arrays.asList(6,10,15);
    }
}
