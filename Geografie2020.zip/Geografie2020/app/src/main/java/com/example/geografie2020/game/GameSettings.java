package com.example.geografie2020.game;

import java.io.Serializable;

public class GameSettings implements Serializable {

    public int nrQuestions;
    public String region;


}